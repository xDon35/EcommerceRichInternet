const express = require("express")
const path = require("path")
const session = require("express-session")
const ejs = require("ejs")
var cookieParser = require('cookie-parser');

var logger = require('morgan');

const app = express()

app.use(session({secret:"aSANJHDFLAKNxalscnasw"}))
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use("/static", express.static(path.join(__dirname,'public')))


var authRouter = require('./routes/auth')
app.use('/auth', authRouter)

app.get('/', (oreq, res)=>{

    res.render("pages/home")
});


  
  

app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
  
    // render the error page
    res.status(err.status || 500);
    res.render('error');
  });


app.listen(3000, ()=>{
    console.log('Server is running at http://localhost:3000')
})