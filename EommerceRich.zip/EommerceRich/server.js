const express = require('express');
const app = express();


// Set the view engine to EJS
app.set('view engine', 'ejs');


// Define a route for the homepage
app.get('/', function(req, res) {
  res.render('home');
});

// Define routes for the other pages
app.get('/about', function(req, res) {
  res.render('about');
});

app.get('/login', function(req, res) {
    res.render('login');
  });

app.get('/registration', function(req, res) {
  res.render('registration');
});

app.get('/contact', function(req, res) {
  res.render('contact');
});

app.get('/shop', function(req, res) {
  res.render('shop');
});




// Start the server
app.listen(3000, function() {
  console.log('Server listening on port 3000');
});